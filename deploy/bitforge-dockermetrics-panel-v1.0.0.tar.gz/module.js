/* [create-plugin] version: 6.7.3 */
/* [create-plugin] plugin: bitforge-dockermetrics-panel@1.0.0 */
define(["@grafana/ui","@emotion/css","module","@grafana/data","react"],(e,t,n,r,o)=>(()=>{"use strict";var a={7(t){t.exports=e},89(e){e.exports=t},308(e){e.exports=n},781(e){e.exports=r},959(e){e.exports=o}},s={};function i(e){var t=s[e];if(void 0!==t)return t.exports;var n=s[e]={exports:{}};return a[e](n,n.exports,i),n.exports}i.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return i.d(t,{a:t}),t},i.d=(e,t)=>{for(var n in t)i.o(t,n)&&!i.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},i.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),i.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},i.p="public/plugins/bitforge-dockermetrics-panel/";var l={};i.r(l),i.d(l,{plugin:()=>q});var c=i(308),d=i.n(c);i.p=d()&&d().uri?d().uri.slice(0,d().uri.lastIndexOf("/")+1):"public/plugins/bitforge-dockermetrics-panel/";var u=i(781);const p={start:"Starting...",stop:"Stopping...",restart:"Restarting...",pause:"Pausing...",unpause:"Resuming..."},m=[{key:"cpuPercent",label:"CPU",unit:"%",color:"#5794F2",format:e=>e.toFixed(1),getValue:e=>e.cpuPercent},{key:"memoryBytes",label:"Memory",unit:"MB",color:"#73BF69",format:e=>(e/1048576).toFixed(0),getValue:e=>e.memoryBytes},{key:"memoryPercent",label:"Memory %",unit:"%",color:"#73BF69",format:e=>e.toFixed(1),getValue:e=>e.memoryPercent},{key:"networkRxBytes",label:"Net RX",unit:"KB/s",color:"#FF9830",format:e=>e.toFixed(1),getValue:e=>e.networkRxBytes,isRate:!0},{key:"networkTxBytes",label:"Net TX",unit:"KB/s",color:"#F2495C",format:e=>e.toFixed(1),getValue:e=>e.networkTxBytes,isRate:!0},{key:"diskReadBytes",label:"Disk Read",unit:"KB/s",color:"#B877D9",format:e=>e.toFixed(1),getValue:e=>e.diskReadBytes,isRate:!0},{key:"diskWriteBytes",label:"Disk Write",unit:"KB/s",color:"#8F3BB8",format:e=>e.toFixed(1),getValue:e=>e.diskWriteBytes,isRate:!0},{key:"uptimeSeconds",label:"Uptime",unit:"h",color:"#888888",format:e=>(e/3600).toFixed(1),getValue:e=>e.uptimeSeconds},{key:"cpuPressureSome",label:"CPU Pressure",unit:"%",color:"#FF6B6B",format:e=>e.toFixed(2),getValue:e=>{var t,n;return null!==(t=null===(n=e.cpuPressure)||void 0===n?void 0:n.some10)&&void 0!==t?t:null}},{key:"cpuPressureFull",label:"CPU Pressure (full)",unit:"%",color:"#EE5A5A",format:e=>e.toFixed(2),getValue:e=>{var t,n;return null!==(t=null===(n=e.cpuPressure)||void 0===n?void 0:n.full10)&&void 0!==t?t:null}},{key:"memoryPressureSome",label:"Mem Pressure",unit:"%",color:"#4ECDC4",format:e=>e.toFixed(2),getValue:e=>{var t,n;return null!==(t=null===(n=e.memoryPressure)||void 0===n?void 0:n.some10)&&void 0!==t?t:null}},{key:"memoryPressureFull",label:"Mem Pressure (full)",unit:"%",color:"#3DBDB5",format:e=>e.toFixed(2),getValue:e=>{var t,n;return null!==(t=null===(n=e.memoryPressure)||void 0===n?void 0:n.full10)&&void 0!==t?t:null}},{key:"ioPressureSome",label:"I/O Pressure",unit:"%",color:"#FFE66D",format:e=>e.toFixed(2),getValue:e=>{var t,n;return null!==(t=null===(n=e.ioPressure)||void 0===n?void 0:n.some10)&&void 0!==t?t:null}},{key:"ioPressureFull",label:"I/O Pressure (full)",unit:"%",color:"#FFD93D",format:e=>e.toFixed(2),getValue:e=>{var t,n;return null!==(t=null===(n=e.ioPressure)||void 0===n?void 0:n.full10)&&void 0!==t?t:null}}],g=["cpuPercent","memoryBytes"],f=[];var h=i(959),b=i.n(h),x=i(89),y=i(7);function v(e,t,n,r,o,a,s){try{var i=e[a](s),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function k(e){return function(){var t=this,n=arguments;return new Promise(function(r,o){var a=e.apply(t,n);function s(e){v(a,r,o,s,i,"next",e)}function i(e){v(a,r,o,s,i,"throw",e)}s(void 0)})}}function w(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function E(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){w(e,t,n[t])})}return e}function N(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}const C=()=>({wrapper:x.css`
      position: relative;
      overflow: auto;
      padding: 10px;
    `,error:x.css`
      color: #ff5555;
      padding: 10px;
    `,info:x.css`
      font-size: 12px;
      margin-bottom: 10px;
    `,loading:x.css`
      padding: 10px;
      color: #888;
    `,hostSection:x.css`
      margin-bottom: 16px;
      &:last-child {
        margin-bottom: 0;
      }
    `,hostHeader:x.css`
      font-size: 13px;
      font-weight: 600;
      padding: 8px 12px;
      margin-bottom: 8px;
      background: rgba(50, 116, 217, 0.15);
      border-left: 3px solid #3274d9;
      border-radius: 0 4px 4px 0;
      display: flex;
      align-items: center;
      gap: 8px;
    `,hostHealthDot:x.css`
      width: 8px;
      height: 8px;
      border-radius: 50%;
    `,containerCount:x.css`
      font-size: 11px;
      color: #888;
      font-weight: normal;
      margin-left: auto;
    `,containersGrid:x.css`
      display: grid;
      gap: 12px;
      padding: 0 4px;
    `,containerCard:x.css`
      background: rgba(255, 255, 255, 0.03);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 6px;
      padding: 12px;
    `,containerHeader:x.css`
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      padding-bottom: 8px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.05);
    `,containerName:x.css`
      font-size: 13px;
      font-weight: 500;
      flex: 1;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    `,containerStatus:x.css`
      font-size: 11px;
      margin-left: 8px;
    `,metricsGrid:x.css`
      display: grid;
      gap: 10px;
    `,metric:x.css`
      background: rgba(0, 0, 0, 0.15);
      border-radius: 4px;
      padding: 8px;
    `,metricHeader:x.css`
      display: flex;
      align-items: center;
      margin-bottom: 4px;
    `,metricColorDot:x.css`
      width: 6px;
      height: 6px;
      border-radius: 50%;
      margin-right: 6px;
    `,metricLabel:x.css`
      font-size: 10px;
      color: #888;
    `,metricValue:x.css`
      font-size: 18px;
      font-weight: 600;
      margin-bottom: 4px;
    `,metricUnit:x.css`
      font-size: 10px;
      color: #888;
      margin-left: 2px;
    `,emptyState:x.css`
      color: #888;
      font-size: 13px;
      text-align: center;
      padding: 40px 20px;
    `,summary:x.css`
      font-size: 11px;
      color: #888;
      padding: 4px 8px;
      margin-bottom: 12px;
      display: flex;
      gap: 16px;
    `,controlsRow:x.css`
      display: flex;
      gap: 4px;
      margin-top: 10px;
      padding-top: 8px;
      border-top: 1px solid rgba(255, 255, 255, 0.05);
    `,controlButton:x.css`
      flex: 1;
      padding: 6px 8px;
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 4px;
      background: rgba(0, 0, 0, 0.2);
      color: #ccc;
      font-size: 10px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      transition: all 0.15s ease;
      &:hover {
        background: rgba(255, 255, 255, 0.1);
        border-color: rgba(255, 255, 255, 0.25);
      }
      &:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
    `,controlButtonStart:x.css`
      &:hover {
        background: rgba(115, 191, 105, 0.2);
        border-color: #73bf69;
        color: #73bf69;
      }
    `,controlButtonStop:x.css`
      &:hover {
        background: rgba(242, 73, 92, 0.2);
        border-color: #f2495c;
        color: #f2495c;
      }
    `,controlButtonRestart:x.css`
      &:hover {
        background: rgba(255, 152, 48, 0.2);
        border-color: #ff9830;
        color: #ff9830;
      }
    `,controlButtonPause:x.css`
      &:hover {
        background: rgba(87, 148, 242, 0.2);
        border-color: #5794f2;
        color: #5794f2;
      }
    `}),P=({data:e,color:t,height:n=40,formatValue:r})=>{if(e.length<2)return null;const o=n-4,a=Math.min(...e),s=Math.max(...e),i=s-a||1,l=e.map((t,n)=>`${n/(e.length-1)*100},${2+o-(t-a)/i*o}`).join(" "),c=r(s),d=r(a);return b().createElement("div",{style:{position:"relative",height:n,display:"flex"}},b().createElement("div",{style:{flex:1,position:"relative",minWidth:0}},b().createElement("svg",{width:"100%",height:n,viewBox:`0 0 100 ${n}`,preserveAspectRatio:"none",style:{display:"block"}},b().createElement("line",{x1:"0",y1:2,x2:"100",y2:2,stroke:"rgba(255,255,255,0.1)",strokeWidth:"0.5",vectorEffect:"non-scaling-stroke"}),b().createElement("line",{x1:"0",y1:2+o/2,x2:"100",y2:2+o/2,stroke:"rgba(255,255,255,0.05)",strokeWidth:"0.5",vectorEffect:"non-scaling-stroke"}),b().createElement("line",{x1:"0",y1:2+o,x2:"100",y2:2+o,stroke:"rgba(255,255,255,0.1)",strokeWidth:"0.5",vectorEffect:"non-scaling-stroke"}),b().createElement("polyline",{fill:"none",stroke:t,strokeWidth:"1.5",points:l,vectorEffect:"non-scaling-stroke"}))),b().createElement("div",{style:{width:"32px",display:"flex",flexDirection:"column",justifyContent:"space-between",fontSize:"8px",color:"#666",textAlign:"right",paddingLeft:"4px",flexShrink:0}},b().createElement("span",null,c),b().createElement("span",null,d)))};function S(e,t,n){if(e.length<2)return[];const r=[];for(let t=1;t<e.length;t++){const o=e[t-1],a=e[t],s=n(o),i=n(a);if(null===s||null===i)continue;const l=(new Date(a.timestamp).getTime()-new Date(o.timestamp).getTime())/1e3;if(l<=0)continue;const c=i-s,d=c>=0?c/l:0;r.push(d/1024)}return r}const O=({hostUrl:e,containerId:t,isRunning:n,isPaused:r,styles:o,pendingAction:a,onPendingStart:s,onPendingComplete:i,onStatusUpdate:l})=>{const c=(0,h.useCallback)(e=>{switch(e){case"start":case"restart":case"unpause":return{expectedRunning:!0,expectedPaused:!1};case"stop":return{expectedRunning:!1,expectedPaused:!1};case"pause":return{expectedRunning:!0,expectedPaused:!0};default:return{expectedRunning:n,expectedPaused:r}}},[n,r]),d=(0,h.useCallback)(n=>k(function*(){const{expectedRunning:r,expectedPaused:o}=c(n);for(let n=0;n<30;n++){try{const n=yield fetch(`${e}/api/containers/${t}/status`);if(n.ok){const e=yield n.json();if(e.isRunning===r&&e.isPaused===o)return null==l||l(e),void i(t)}}catch(e){}yield new Promise(e=>setTimeout(e,500))}i(t)})(),[e,t,c,l,i]),u=n=>k(function*(){s(t,n);try{const r=yield fetch(`${e}/api/containers/${t}/${n}`,{method:"POST"});if(r.ok)d(n);else{const e=yield r.json();console.error(`Failed to ${n} container:`,e.error),i(t)}}catch(e){console.error(`Failed to ${n} container:`,e),i(t)}})(),p=null!==a;return b().createElement("div",{className:o.controlsRow},n?b().createElement("button",{className:`${o.controlButton} ${o.controlButtonStop}`,onClick:()=>u("stop"),disabled:p,title:"Stop container"},"stop"===(null==a?void 0:a.action)?"...":"■ Stop"):b().createElement("button",{className:`${o.controlButton} ${o.controlButtonStart}`,onClick:()=>u("start"),disabled:p,title:"Start container"},"start"===(null==a?void 0:a.action)?"...":"▶ Start"),b().createElement("button",{className:`${o.controlButton} ${o.controlButtonRestart}`,onClick:()=>u("restart"),disabled:p||!n,title:"Restart container"},"restart"===(null==a?void 0:a.action)?"...":"↻ Restart"),r?b().createElement("button",{className:`${o.controlButton} ${o.controlButtonStart}`,onClick:()=>u("unpause"),disabled:p,title:"Unpause container"},"unpause"===(null==a?void 0:a.action)?"...":"▶ Unpause"):b().createElement("button",{className:`${o.controlButton} ${o.controlButtonPause}`,onClick:()=>u("pause"),disabled:p||!n,title:"Pause container"},"pause"===(null==a?void 0:a.action)?"...":"⏸ Pause"))};function j(e,t,n,r,o,a,s){try{var i=e[a](s),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function I(e){return function(){var t=this,n=arguments;return new Promise(function(r,o){var a=e.apply(t,n);function s(e){j(a,r,o,s,i,"next",e)}function i(e){j(a,r,o,s,i,"throw",e)}s(void 0)})}}function D(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function F(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){D(e,t,n[t])})}return e}function B(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}const A={container:x.css`
    padding: 8px 0;
  `,hostList:x.css`
    margin-bottom: 12px;
  `,hostItem:x.css`
    display: flex;
    align-items: center;
    padding: 8px;
    margin-bottom: 4px;
    background: rgba(255, 255, 255, 0.05);
    border-radius: 4px;
  `,healthIndicator:x.css`
    width: 8px;
    height: 8px;
    border-radius: 50%;
    margin-right: 8px;
    flex-shrink: 0;
  `,healthy:x.css`
    background-color: #73BF69;
  `,unhealthy:x.css`
    background-color: #FF5555;
  `,unknown:x.css`
    background-color: #888;
  `,hostInfo:x.css`
    flex: 1;
    min-width: 0;
  `,hostName:x.css`
    font-weight: 500;
    margin-bottom: 2px;
  `,hostUrl:x.css`
    font-size: 11px;
    color: #888;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  `,hostMeta:x.css`
    font-size: 11px;
    color: #888;
    margin-left: 8px;
    text-align: right;
    min-width: 80px;
  `,hostVersion:x.css`
    font-size: 10px;
    color: #666;
  `,enabledToggle:x.css`
    margin-left: 8px;
    cursor: pointer;
  `,removeButton:x.css`
    background: none;
    border: none;
    color: #FF5555;
    cursor: pointer;
    padding: 4px 8px;
    font-size: 14px;
    &:hover {
      color: #FF7777;
    }
  `,addForm:x.css`
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 8px;
    background: rgba(255, 255, 255, 0.03);
    border-radius: 4px;
  `,input:x.css`
    padding: 6px 8px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 4px;
    background: rgba(0, 0, 0, 0.2);
    color: inherit;
    font-size: 13px;
    &:focus {
      outline: none;
      border-color: rgba(255, 255, 255, 0.3);
    }
  `,buttonRow:x.css`
    display: flex;
    gap: 8px;
  `,addButton:x.css`
    padding: 6px 12px;
    background: #3274D9;
    border: none;
    border-radius: 4px;
    color: white;
    cursor: pointer;
    font-size: 13px;
    &:hover {
      background: #4285EA;
    }
    &:disabled {
      background: #555;
      cursor: not-allowed;
    }
  `,cancelButton:x.css`
    padding: 6px 12px;
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.2);
    border-radius: 4px;
    color: inherit;
    cursor: pointer;
    font-size: 13px;
    &:hover {
      background: rgba(255, 255, 255, 0.05);
    }
  `,showFormButton:x.css`
    padding: 6px 12px;
    background: transparent;
    border: 1px dashed rgba(255, 255, 255, 0.2);
    border-radius: 4px;
    color: #888;
    cursor: pointer;
    font-size: 13px;
    width: 100%;
    &:hover {
      background: rgba(255, 255, 255, 0.05);
      color: inherit;
    }
  `,error:x.css`
    color: #FF5555;
    font-size: 12px;
    padding: 4px 0;
  `,emptyState:x.css`
    color: #888;
    font-size: 12px;
    padding: 8px 0;
    text-align: center;
  `};const $=({hosts:e,onHostsChange:t})=>{const[n,r]=(0,h.useState)(new Map),[o,a]=(0,h.useState)(!1),[s,i]=(0,h.useState)(""),[l,c]=(0,h.useState)(""),[d,u]=(0,h.useState)(null),p=(0,h.useCallback)(()=>I(function*(){const t=new Map;yield Promise.all(e.map(e=>I(function*(){const n=B(F({},e),{isHealthy:!1,lastError:null,hostname:null,agentVersion:null,dockerVersion:null,psiSupported:!1,containerCount:0});try{const t=yield fetch(`${e.url}/api/info`,{signal:AbortSignal.timeout(15e3)});if(t.ok){const e=yield t.json();n.isHealthy=e.dockerConnected,n.hostname=e.hostname,n.agentVersion=e.agentVersion,n.dockerVersion=e.dockerVersion,n.psiSupported=e.psiSupported}else n.lastError=`HTTP ${t.status}`}catch(e){n.lastError=e instanceof Error?e.message:"Connection failed"}t.set(e.id,n)})())),r(t)})(),[e]);(0,h.useEffect)(()=>{p();const e=setInterval(p,6e4);return()=>clearInterval(e)},[p]);const m=e=>{const t=n.get(e);return t?t.isHealthy?A.healthy:A.unhealthy:A.unknown};return b().createElement("div",{className:A.container},d&&b().createElement("div",{className:A.error},d),b().createElement("div",{className:A.hostList},0===e.length&&b().createElement("div",{className:A.emptyState},"No agents configured. Add a Docker Metrics Agent to get started."),e.map(r=>{const o=(e=>{const t=n.get(e);return t?t.lastError?{containers:"-",version:t.lastError}:{containers:`${t.containerCount} containers`,version:t.agentVersion?`v${t.agentVersion}`:""}:{containers:"-",version:"Checking..."}})(r.id);return b().createElement("div",{key:r.id,className:A.hostItem},b().createElement("div",{className:`${A.healthIndicator} ${m(r.id)}`}),b().createElement("div",{className:A.hostInfo},b().createElement("div",{className:A.hostName},r.name,!r.enabled&&" (disabled)"),b().createElement("div",{className:A.hostUrl},r.url)),b().createElement("div",{className:A.hostMeta},b().createElement("div",null,o.containers),b().createElement("div",{className:A.hostVersion},o.version)),b().createElement("input",{type:"checkbox",className:A.enabledToggle,checked:r.enabled,onChange:()=>{return n=r.id,void t(e.map(e=>e.id===n?B(F({},e),{enabled:!e.enabled}):e));var n},title:r.enabled?"Disable host":"Enable host"}),b().createElement("button",{className:A.removeButton,onClick:()=>{return n=r.id,void t(e.filter(e=>e.id!==n));var n},title:"Remove host"},"×"))})),o?b().createElement("div",{className:A.addForm},b().createElement("input",{className:A.input,type:"text",placeholder:"Host name (e.g., Production Server)",value:s,onChange:e=>i(e.target.value)}),b().createElement("input",{className:A.input,type:"text",placeholder:"Agent URL (e.g., http://192.168.1.10:5000)",value:l,onChange:e=>c(e.target.value)}),b().createElement("div",{className:A.buttonRow},b().createElement("button",{className:A.addButton,onClick:()=>{if(!s.trim()||!l.trim())return;let n=l.trim();if(n.endsWith("/")&&(n=n.slice(0,-1)),e.some(e=>e.url.toLowerCase()===n.toLowerCase()))return void u("A host with this URL already exists");const r={id:"xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g,e=>{const t=16*Math.random()|0;return("x"===e?t:3&t|8).toString(16)}),name:s.trim(),url:n,enabled:!0};t([...e,r]),i(""),c(""),a(!1),u(null)},disabled:!s.trim()||!l.trim()},"Add Agent"),b().createElement("button",{className:A.cancelButton,onClick:()=>{a(!1),i(""),c(""),u(null)}},"Cancel"))):b().createElement("button",{className:A.showFormButton,onClick:()=>a(!0)},"+ Add Docker Metrics Agent"))},M=({value:e,onChange:t})=>b().createElement($,{hosts:e||f,onHostsChange:e=>t(e)});function R(e,t,n,r,o,a,s){try{var i=e[a](s),l=i.value}catch(e){return void n(e)}i.done?t(l):Promise.resolve(l).then(r,o)}function z(e){return function(){var t=this,n=arguments;return new Promise(function(r,o){var a=e.apply(t,n);function s(e){R(a,r,o,s,i,"next",e)}function i(e){R(a,r,o,s,i,"throw",e)}s(void 0)})}}function V(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function L(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){V(e,t,n[t])})}return e}function U(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}const T={container:x.css`
    padding: 8px 0;
  `,allContainersToggle:x.css`
    display: flex;
    align-items: center;
    padding: 10px 8px;
    margin-bottom: 8px;
    background: rgba(50, 116, 217, 0.1);
    border: 1px solid rgba(50, 116, 217, 0.3);
    border-radius: 4px;
    cursor: pointer;
    &:hover {
      background: rgba(50, 116, 217, 0.15);
    }
  `,allContainersToggleActive:x.css`
    background: rgba(50, 116, 217, 0.25);
    border-color: rgba(50, 116, 217, 0.5);
  `,checkbox:x.css`
    margin-right: 8px;
    width: 16px;
    height: 16px;
    cursor: pointer;
  `,allContainersLabel:x.css`
    font-size: 13px;
    font-weight: 500;
  `,allContainersDescription:x.css`
    font-size: 11px;
    color: #888;
    margin-left: auto;
  `,search:x.css`
    width: 100%;
    padding: 8px;
    margin-bottom: 8px;
    border: 1px solid rgba(255, 255, 255, 0.1);
    border-radius: 4px;
    background: rgba(0, 0, 0, 0.2);
    color: inherit;
    font-size: 13px;
    &:focus {
      outline: none;
      border-color: rgba(255, 255, 255, 0.3);
    }
    &:disabled {
      opacity: 0.5;
    }
  `,hostGroup:x.css`
    margin-bottom: 12px;
  `,hostHeader:x.css`
    display: flex;
    align-items: center;
    font-size: 11px;
    color: #888;
    margin-bottom: 4px;
    padding: 4px 8px;
    background: rgba(255, 255, 255, 0.03);
    border-radius: 4px;
  `,hostName:x.css`
    flex: 1;
  `,selectAllHost:x.css`
    font-size: 10px;
    color: #3274d9;
    cursor: pointer;
    &:hover {
      text-decoration: underline;
    }
  `,containerList:x.css`
    max-height: 300px;
    overflow-y: auto;
  `,containerItem:x.css`
    display: flex;
    align-items: center;
    padding: 8px;
    cursor: pointer;
    border-radius: 4px;
    &:hover {
      background: rgba(255, 255, 255, 0.05);
    }
  `,containerItemSelected:x.css`
    background: rgba(50, 116, 217, 0.2);
    &:hover {
      background: rgba(50, 116, 217, 0.3);
    }
  `,containerItemDisabled:x.css`
    opacity: 0.5;
    cursor: not-allowed;
  `,containerName:x.css`
    flex: 1;
    font-size: 13px;
  `,containerId:x.css`
    font-size: 11px;
    color: #888;
    font-family: monospace;
  `,loading:x.css`
    color: #888;
    font-size: 12px;
    padding: 8px;
  `,error:x.css`
    color: #ff5555;
    font-size: 12px;
    padding: 8px;
  `,emptyState:x.css`
    color: #888;
    font-size: 12px;
    padding: 8px;
    text-align: center;
  `,selectedCount:x.css`
    font-size: 11px;
    color: #888;
    padding: 4px 8px;
    margin-bottom: 8px;
  `},H=({hosts:e,selectedContainerIds:t,showAllContainers:n,onSelectionChange:r,onShowAllChange:o})=>{const[a,s]=(0,h.useState)([]),[i,l]=(0,h.useState)(!1),[c,d]=(0,h.useState)(null),[u,p]=(0,h.useState)(""),m=(0,h.useMemo)(()=>e.filter(e=>e.enabled),[e]),g=(0,h.useCallback)(()=>z(function*(){if(0!==m.length){l(!0),d(null);try{const e=[];yield Promise.all(m.map(t=>z(function*(){try{const n=yield fetch(`${t.url}/api/containers?all=true`,{signal:AbortSignal.timeout(15e3)});if(n.ok){const r=yield n.json();for(const n of r)e.push(U(L({},n),{hostId:t.id,hostName:t.name}))}}catch(e){}})())),s(e)}catch(e){d(e instanceof Error?e.message:"Failed to fetch containers")}finally{l(!1)}}else s([])})(),[m]);(0,h.useEffect)(()=>{g();const e=setInterval(g,3e4);return()=>clearInterval(e)},[g]);const f=a.filter(e=>{const t=u.toLowerCase();return e.containerName.toLowerCase().includes(t)||e.containerId.toLowerCase().includes(t)||e.hostName.toLowerCase().includes(t)}).reduce((e,t)=>{const n=`${t.hostId}:${t.hostName}`;return e[n]||(e[n]=[]),e[n].push(t),e},{}),x=e=>{if(n)return;const o=t.includes(e)?t.filter(t=>t!==e):[...t,e];r(o)};return 0===m.length?b().createElement("div",{className:T.emptyState},"Configure and enable agents first in the Agents section"):b().createElement("div",{className:T.container},b().createElement("div",{className:`${T.allContainersToggle} ${n?T.allContainersToggleActive:""}`,onClick:()=>o(!n)},b().createElement("input",{type:"checkbox",className:T.checkbox,checked:n,onChange:e=>o(e.target.checked),onClick:e=>e.stopPropagation()}),b().createElement("span",{className:T.allContainersLabel},"All Containers"),b().createElement("span",{className:T.allContainersDescription},"Auto-include new containers")),!n&&b().createElement("div",{className:T.selectedCount},t.length," container",1!==t.length?"s":""," selected"),b().createElement("input",{className:T.search,type:"text",placeholder:"Search containers...",value:u,onChange:e=>p(e.target.value),disabled:n}),c&&b().createElement("div",{className:T.error},c),i&&0===a.length&&b().createElement("div",{className:T.loading},"Loading containers..."),!i&&0===a.length&&b().createElement("div",{className:T.emptyState},"No containers found on enabled agents"),b().createElement("div",{className:T.containerList},Object.entries(f).map(([e,o])=>{const[,a]=e.split(":"),s=o.every(e=>t.includes(e.containerId));return b().createElement("div",{key:e,className:T.hostGroup},b().createElement("div",{className:T.hostHeader},b().createElement("span",{className:T.hostName},a," (",o.length,")"),!n&&b().createElement("span",{className:T.selectAllHost,onClick:()=>(e=>{if(n)return;const o=e.map(e=>e.containerId);if(o.every(e=>t.includes(e)))r(t.filter(e=>!o.includes(e)));else{const e=[...new Set([...t,...o])];r(e)}})(o)},s?"Deselect all":"Select all")),o.map(e=>{const r=t.includes(e.containerId);return b().createElement("div",{key:e.containerId,className:`${T.containerItem} ${r||n?T.containerItemSelected:""} ${n?T.containerItemDisabled:""}`,onClick:()=>x(e.containerId)},b().createElement("input",{type:"checkbox",className:T.checkbox,checked:r||n,disabled:n,onChange:()=>x(e.containerId),onClick:e=>e.stopPropagation()}),b().createElement("div",{className:T.containerName},e.containerName.replace(/^\//,"")),b().createElement("div",{className:T.containerId},e.containerId.substring(0,12)))}))})))};function W(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function G(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),n.push.apply(n,r)}return n}(Object(t)).forEach(function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))}),e}const K=({value:e,onChange:t,context:n})=>{var r,o;return b().createElement(H,{hosts:(null===(r=n.options)||void 0===r?void 0:r.hosts)||f,selectedContainerIds:e||[],showAllContainers:(null===(o=n.options)||void 0===o?void 0:o.showAllContainers)||!1,onSelectionChange:e=>t(e),onShowAllChange:e=>{n.options&&"function"==typeof n.onOptionsChange&&n.onOptionsChange(G(function(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter(function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable}))),r.forEach(function(t){W(e,t,n[t])})}return e}({},n.options),{showAllContainers:e}))}})},_={container:x.css`
    padding: 8px 0;
  `,header:x.css`
    font-size: 11px;
    color: #888;
    margin-bottom: 8px;
  `,metricList:x.css`
    display: flex;
    flex-direction: column;
    gap: 4px;
  `,metricItem:x.css`
    display: flex;
    align-items: center;
    padding: 6px 8px;
    cursor: pointer;
    border-radius: 4px;
    &:hover {
      background: rgba(255, 255, 255, 0.05);
    }
  `,metricItemSelected:x.css`
    background: rgba(50, 116, 217, 0.2);
    &:hover {
      background: rgba(50, 116, 217, 0.3);
    }
  `,checkbox:x.css`
    margin-right: 8px;
    width: 14px;
    height: 14px;
    cursor: pointer;
  `,colorDot:x.css`
    width: 10px;
    height: 10px;
    border-radius: 50%;
    margin-right: 8px;
  `,metricLabel:x.css`
    flex: 1;
    font-size: 12px;
  `,metricUnit:x.css`
    font-size: 10px;
    color: #888;
    margin-left: 8px;
  `,actions:x.css`
    display: flex;
    gap: 12px;
    margin-top: 8px;
    padding-top: 8px;
    border-top: 1px solid rgba(255, 255, 255, 0.1);
  `,actionLink:x.css`
    font-size: 11px;
    color: #3274d9;
    cursor: pointer;
    &:hover {
      text-decoration: underline;
    }
  `,selectedCount:x.css`
    font-size: 11px;
    color: #888;
    margin-left: auto;
  `},X=({selectedMetrics:e,onChange:t})=>{const n=n=>{e.includes(n)?t(e.filter(e=>e!==n)):t([...e,n])};return b().createElement("div",{className:_.container},b().createElement("div",{className:_.header},"Select metrics to display for each container"),b().createElement("div",{className:_.metricList},m.map(t=>{const r=e.includes(t.key);return b().createElement("div",{key:t.key,className:`${_.metricItem} ${r?_.metricItemSelected:""}`,onClick:()=>n(t.key)},b().createElement("input",{type:"checkbox",className:_.checkbox,checked:r,onChange:()=>n(t.key),onClick:e=>e.stopPropagation()}),b().createElement("span",{className:_.colorDot,style:{background:t.color}}),b().createElement("span",{className:_.metricLabel},t.label),b().createElement("span",{className:_.metricUnit},t.unit))})),b().createElement("div",{className:_.actions},b().createElement("span",{className:_.actionLink,onClick:()=>{t(m.map(e=>e.key))}},"Select all"),b().createElement("span",{className:_.actionLink,onClick:()=>{t([])}},"Clear"),b().createElement("span",{className:_.actionLink,onClick:()=>{t(["cpuPercent","memoryBytes"])}},"Defaults"),b().createElement("span",{className:_.selectedCount},e.length," selected")))},Y=({value:e,onChange:t})=>b().createElement(X,{selectedMetrics:e||["cpuPercent","memoryBytes"],onChange:t}),q=new u.PanelPlugin(({width:e,height:t,options:n,timeRange:r})=>{const o=(0,h.useMemo)(()=>n.hosts||f,[n.hosts]),a=(0,h.useMemo)(()=>o.filter(e=>e.enabled),[o]),s=n.containersPerRow||0,i=n.metricsPerRow||0,l=(0,y.useStyles2)(C),c={gridTemplateColumns:s>0?`repeat(${s}, 1fr)`:"repeat(auto-fill, minmax(300px, 1fr))"},d={gridTemplateColumns:i>0?`repeat(${i}, 1fr)`:"repeat(auto-fill, minmax(120px, 1fr))"},[u,v]=(0,h.useState)([]),[w,j]=(0,h.useState)([]),[I,D]=(0,h.useState)(null),[F,B]=(0,h.useState)(!1),[A,$]=(0,h.useState)(new Map),[M,R]=(0,h.useState)(new Map),z=(0,h.useCallback)(e=>{$(t=>{const n=new Map(t);return n.set(e.containerId,e),n})},[]),V=(0,h.useCallback)((e,t)=>{R(n=>{const r=new Map(n);return r.set(e,{action:t,startTime:Date.now()}),r})},[]),L=(0,h.useCallback)(e=>{R(t=>{const n=new Map(t);return n.delete(e),n})},[]),U=(0,h.useMemo)(()=>{const e=n.selectedMetrics||g;return m.filter(t=>e.includes(t.key))},[n.selectedMetrics]);(0,h.useEffect)(()=>{const e=()=>k(function*(){if(0!==a.length)try{const e=[];yield Promise.all(a.map(t=>k(function*(){try{const n=yield fetch(`${t.url}/api/containers?all=true`,{signal:AbortSignal.timeout(15e3)});if(n.ok){const r=yield n.json();for(const n of r)e.push(N(E({},n),{hostId:t.id,hostName:t.name}))}}catch(e){}})())),j(e)}catch(e){}else j([])})();e();const t=setInterval(e,3e4);return()=>clearInterval(t)},[a]);const T=(0,h.useMemo)(()=>n.showAllContainers?w.map(e=>e.containerId):n.containerIds||[],[n.showAllContainers,n.containerIds,w]);(0,h.useEffect)(()=>{const e=()=>k(function*(){if(0===a.length)return D("No agents configured. Add Docker Metrics Agents in panel options."),void v([]);if(0===T.length&&!n.showAllContainers)return D('No containers selected. Enable "Show All Containers" or select specific containers.'),void v([]);B(!0),D(null);try{const e=r.from.toISOString(),t=r.to.toISOString(),n=[];yield Promise.all(a.map(r=>k(function*(){try{const o=`${r.url}/api/metrics?from=${e}&to=${t}`,a=yield fetch(o,{signal:AbortSignal.timeout(15e3)});if(a.ok){const e=yield a.json();for(const t of e)T.includes(t.containerId)&&n.push(N(E({},t),{hostId:r.id,hostName:r.name}))}}catch(e){}})())),v(n),$(new Map)}catch(e){D(e instanceof Error?e.message:"Failed to fetch metrics"),v([])}finally{B(!1)}})();e();const t=setInterval(e,1e4);return()=>clearInterval(t)},[a,T,n.showAllContainers,r.from.valueOf(),r.to.valueOf()]);const H=(0,h.useMemo)(()=>{const e=new Map;for(const t of o)e.set(t.id,t.url);return e},[o]),W=(0,h.useMemo)(()=>{const e=new Map;for(const t of w)(n.showAllContainers||(n.containerIds||[]).includes(t.containerId))&&e.set(t.containerId,{containerId:t.containerId,containerName:t.containerName,hostId:t.hostId,hostName:t.hostName,hostUrl:H.get(t.hostId)||"",metrics:[],latest:null,rateData:new Map,latestRates:new Map});for(const t of u){const n=e.get(t.containerId);n&&n.metrics.push(t)}for(const t of e.values())if(t.metrics.length>0){t.metrics.sort((e,t)=>new Date(e.timestamp).getTime()-new Date(t.timestamp).getTime()),t.latest=t.metrics[t.metrics.length-1];for(const e of m.filter(e=>e.isRate)){const n=S(t.metrics,e.key,e.getValue);t.rateData.set(e.key,n),n.length>0&&t.latestRates.set(e.key,n[n.length-1])}}const t=new Map;for(const n of e.values()){const e=n.hostId;t.has(e)||t.set(e,{hostId:n.hostId,hostName:n.hostName,hostUrl:n.hostUrl,containers:[]}),t.get(e).containers.push(n)}for(const e of t.values())e.containers.sort((e,t)=>e.containerName.localeCompare(t.containerName));return Array.from(t.values()).sort((e,t)=>e.hostName.localeCompare(t.hostName))},[w,u,n.showAllContainers,n.containerIds,H]),G=W.reduce((e,t)=>e+t.containers.length,0),K=W.length;return I?b().createElement("div",{className:(0,x.cx)(l.wrapper,x.css`width: ${e}px; height: ${t}px;`)},b().createElement("div",{className:l.error},b().createElement("strong",null,"Error:")," ",I),b().createElement("div",{className:l.info},b().createElement("p",null,"Configuration:"),b().createElement("ul",null,b().createElement("li",null,"Agents: ",a.length," enabled"),b().createElement("li",null,"Show All: ",n.showAllContainers?"Yes":"No"),b().createElement("li",null,"Selected: ",(n.containerIds||[]).length," containers")))):F&&0===u.length&&T.length>0?b().createElement("div",{className:(0,x.cx)(l.wrapper,x.css`width: ${e}px; height: ${t}px;`)},b().createElement("div",{className:l.loading},"Loading metrics from ",a.length," agent(s)...")):0===G?b().createElement("div",{className:(0,x.cx)(l.wrapper,x.css`width: ${e}px; height: ${t}px;`)},b().createElement("div",{className:l.emptyState},"No containers to display.",b().createElement("br",null),b().createElement("span",{style:{fontSize:"11px"}},0===a.length?"Add and enable Docker Metrics Agents in panel options.":n.showAllContainers?"Waiting for containers to be discovered...":'Select containers in panel options or enable "Show All Containers".'))):0===U.length?b().createElement("div",{className:(0,x.cx)(l.wrapper,x.css`width: ${e}px; height: ${t}px;`)},b().createElement("div",{className:l.emptyState},"No metrics selected.",b().createElement("br",null),b().createElement("span",{style:{fontSize:"11px"}},'Select metrics to display in panel options under "Display".'))):b().createElement("div",{className:(0,x.cx)(l.wrapper,x.css`width: ${e}px; height: ${t}px;`)},b().createElement("div",{className:l.summary},b().createElement("span",null,K," host",1!==K?"s":""),b().createElement("span",null,G," container",1!==G?"s":""),b().createElement("span",null,U.length," metrics"),b().createElement("span",null,u.length," samples")),W.map(e=>b().createElement("div",{key:e.hostId,className:l.hostSection},b().createElement("div",{className:l.hostHeader},b().createElement("span",{className:l.hostHealthDot,style:{background:"#73BF69"}}),e.hostName,b().createElement("span",{className:l.containerCount},e.containers.length," container",1!==e.containers.length?"s":"")),b().createElement("div",{className:l.containersGrid,style:c},e.containers.map(e=>{var t,r,o,a,s,i;const c=A.get(e.containerId),u=null!==(t=null!==(r=null==c?void 0:c.isRunning)&&void 0!==r?r:null===(s=e.latest)||void 0===s?void 0:s.isRunning)&&void 0!==t&&t,m=null!==(o=null!==(a=null==c?void 0:c.isPaused)&&void 0!==a?a:null===(i=e.latest)||void 0===i?void 0:i.isPaused)&&void 0!==o&&o,g=M.get(e.containerId)||null,f=g?{label:`⏳ ${p[g.action]}`,color:"#FF9830"}:m?{label:"● Paused",color:"#FF9830"}:u?{label:"● Running",color:"#73BF69"}:{label:"● Stopped",color:"#FF5555"};return b().createElement("div",{key:e.containerId,className:l.containerCard},b().createElement("div",{className:l.containerHeader},b().createElement("span",{className:l.containerName,title:e.containerName},e.containerName.replace(/^\//,"")),b().createElement("span",{className:l.containerStatus,style:{color:f.color}},f.label)),b().createElement("div",{className:l.metricsGrid,style:d},U.map(t=>((e,t)=>{const n=e.latest;if(t.isRate){const n=e.rateData.get(t.key)||[],r=e.latestRates.get(t.key);if(void 0===r&&0===n.length)return null;const o=void 0!==r?r:0;return b().createElement("div",{key:t.key,className:l.metric},b().createElement("div",{className:l.metricHeader},b().createElement("span",{className:l.metricColorDot,style:{background:t.color}}),b().createElement("span",{className:l.metricLabel},t.label)),b().createElement("div",{className:l.metricValue},o.toFixed(1),b().createElement("span",{className:l.metricUnit},t.unit)),n.length>1&&b().createElement(P,{data:n,color:t.color,formatValue:e=>e.toFixed(1)}))}const r=n?t.getValue(n):null;if(null==r)return null;const o=e.metrics.map(e=>t.getValue(e)).filter(e=>null!=e);return b().createElement("div",{key:t.key,className:l.metric},b().createElement("div",{className:l.metricHeader},b().createElement("span",{className:l.metricColorDot,style:{background:t.color}}),b().createElement("span",{className:l.metricLabel},t.label)),b().createElement("div",{className:l.metricValue},t.format(r),b().createElement("span",{className:l.metricUnit},t.unit)),o.length>1&&b().createElement(P,{data:o,color:t.color,formatValue:t.format}))})(e,t))),n.enableContainerControls&&e.hostUrl&&b().createElement(O,{hostUrl:e.hostUrl,containerId:e.containerId,isRunning:u,isPaused:m,styles:l,pendingAction:g,onPendingStart:V,onPendingComplete:L,onStatusUpdate:z}))})))))}).setPanelOptions(e=>e.addCustomEditor({id:"hostManager",path:"hosts",name:"Docker Metrics Agents",description:"Configure agents running on each Docker host",category:["Agents"],editor:M,defaultValue:f}).addBooleanSwitch({path:"showAllContainers",name:"Show All Containers",description:"Automatically include all containers (including new ones)",defaultValue:!0,category:["Containers"]}).addCustomEditor({id:"containerSelector",path:"containerIds",name:"Select Containers",description:"Choose which containers to display metrics for",category:["Containers"],editor:K}).addCustomEditor({id:"metricSelector",path:"selectedMetrics",name:"Display Metrics",description:"Choose which metrics to show for each container",category:["Display"],editor:Y,defaultValue:g}).addNumberInput({path:"containersPerRow",name:"Containers per row",description:"Number of container cards per row (0 = auto)",defaultValue:0,category:["Layout"],settings:{min:0,max:10,integer:!0}}).addNumberInput({path:"metricsPerRow",name:"Metrics per row",description:"Number of metrics per row within each container card (0 = auto)",defaultValue:0,category:["Layout"],settings:{min:0,max:8,integer:!0}}).addBooleanSwitch({path:"enableContainerControls",name:"Enable Container Controls",description:"Show start/stop/restart/pause buttons for each container",defaultValue:!1,category:["Controls"]}));return l})());
//# sourceMappingURL=module.js.map